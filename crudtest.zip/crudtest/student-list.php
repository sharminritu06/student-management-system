<?php 
//include_once('./includes/database.php');
include_once('./includes/header.php');

/* -----------------------Record Delete Code------------------------*/

if(isset($_REQUEST['act']) && $_REQUEST['act']=='del'){
    $id= $_REQUEST['studentid'];
    $query ="DELETE FROM students WHERE id= $id";
    $rec = mysqli_query($conn, $query);
    if($rec){
         echo "<script>window.location='student-list.php'</script>";
    } else{
        echo "Something went Wrong";
    }
}



?>
<div class="container" style="height:auto;">
    <div class="row">
        <div class="col-lg-12">
            <a href="index.php" class="btn btn-info">Add New </a><br/>
            <table class="table table-bordered" style="100%">
                <thead>
                    <tr>
                        <th>S.No.</th>
                        <th>Name</th>
                        <th>Age</th>
                        <th>Contact</th> 
                        <th colspan="2" style="text-align: center;">Action</th>
                    </tr>
                    
                </thead>
                <?php 
                    //echo "<pre/>";
                    $query = "SELECT * FROM students ORDER BY name";
                    $result = mysqli_query($conn,$query);
                    //$student = mysqli_fetch_assoc($result);
                      $sn=1;  
                    while($student =mysqli_fetch_assoc($result)){ 
                    //print_r($student);
?>
                        <tr>
                            <td><?php echo $sn; ?></td>
                            <td><?php echo $student['name']; ?></td>
                            <td><?php echo $student['age']; ?></td>
                             <td><?php echo $student['contact']; ?></td>
                             
                             <td><a href="edit-details.php?studentid=<?php echo $student['id']?>&age=<?php echo $student['age'];?>">Edit</a></td>

                             <td><a href="student-list.php?studentid=<?php echo $student['id']?>&act=del">Delete</a></td>
                        </tr>
                    <?php $sn++;}
                    
                ?>
            </table>
        </div>
    </div>
</div>
<?php include_once('./includes/footer.php');
?>