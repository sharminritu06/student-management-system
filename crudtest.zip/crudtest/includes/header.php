<?php  include_once('database.php');?>
<html>
<head>
<title>Student List</title>
<link href='./css/bootstrap.min.css' rel="stylesheet"/>

</head>

<body>
    <header>
    <div class="header" style="height:50px; background-color:#000; text-align:center; color:#fff; padding: 1px 1px 20px 15px;"> 
        <div class="row">
            <div class="col-lg-12">
                <h1>Welcome</h1>
            </div>
        </div>
</div>
    </header>