<footer>
<div class="container" style="height: 50px;background-color: #000;color: #fff;padding: 1px 0px 10px 21px;text-align: center;">
   <div class="row">
            <div class="col-lg-12">
               &copy; All Rights Reserved
            </div>
   </div> 
</div>
</footer>
</body>
</html>