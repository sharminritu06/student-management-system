<?php 

if(isset($_POST['save'])){

    $name =$_POST['name'];
    $age =$_POST['age'];
    $contact =$_POST['contact'];
    
  $query= "INSERT INTO students(name, age, contact) VALUES('$name', $age,'$contact')";
  // exit();
    $last= mysqli_query($conn,$query);
    if($last){
        echo "<script>window.location='student-list.php'</script>";
    } else{
        echo "Something went Wrong";
    }

}
    
?>
<div class="container" style="height:500px;">

<a href="student-list.php" class="btn btn-info">Student List</a>
<form class="form-group" method="post" >
    <div class="row">
        <div class="col-lg-6">
            <label>Name : </label>
            <input type="text" name="name" id='name' class="form-control" />
        </div>        
        <div class="col-lg-6">
            <label>Age : </label>
            <input type="text" name="age" id='age' class="form-control" />
        </div>
        <div class="col-lg-6">
            <label>Contact No. : </label>
            <input type="text" name="contact" id='contact' class="form-control" />
        </div>
        <div class="col-lg-11">
                <input type="submit" name="save" value="Save" class='btn btn-info' />
        </div>       
    </div>
</form>
</div>